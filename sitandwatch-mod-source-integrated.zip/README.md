# Something Wants You To Sit And Watch

Minecraft Forge 1.20.1 mod source project.

## Latest source changes

- Ron remains beside the couch after he wakes up; his AI is kept disabled until the later story sequence removes him.
- Day 3 now requires the player to find Smug Bro and right-click him to ask where Ron is before the couch can be unzipped.
- Smug Bro wanders among villagers during the search phase, then leads the player to the couch.
- Older saves that had already advanced the previous Day 3 phase are returned to the new conversation step, provided the couch has not already been unzipped.
- A random one of the 16 village houses becomes the unlocked player home, with a bed and respawn point. The other village houses remain locked.
- The GitHub Actions workflow extracts the newest `sitandwatch-mod-source*.zip` in the repository root and publishes the built artifact as `Sit-and-watch.jar`.

## Build

Use the repository's `.github/workflows/build.yml` workflow, or run `gradle build --no-daemon` with JDK 17 and Gradle 8.1.1.

## Integrated features in this source package

- LuxuryLighting dynamic item lighting is integrated into the Sit and Watch JAR. Held and dropped light-emitting block-items provide client-side local light.
- First-time joining players receive one torch and one spyglass.
- New Overworld worlds use a fixed Plains biome source; existing generated chunks are not retroactively replaced.
- `COPYRIGHT.txt` is placed at the JAR root, with an additional nested ownership notice and per-model metadata/sidecar notices.
- The release artifact name is always `Sit-and-watch.jar` (no version in the file name).

The original uploaded LuxuryLighting source archive contained only the compiled JAR, so its small dynamic-lighting class was recreated from the supplied bytecode and its LevelRenderer Mixin/refmap were retained.
