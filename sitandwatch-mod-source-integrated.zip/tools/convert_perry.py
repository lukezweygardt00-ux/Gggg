#!/usr/bin/env python3
"""Convert the supplied Perry Blockbench model into the mod's packed mesh format.

Run from any directory:
    python tools/convert_perry.py

The source model is tools/source_models/jerry_normal.bbmodel. Its embedded
texture is extracted to assets/sitandwatch/textures/entity/perry_wolf.png.
"""
from __future__ import annotations

import base64
import json
import math
import struct
from pathlib import Path
from io import BytesIO

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tools" / "source_models" / "jerry_normal.bbmodel"
ASSETS = ROOT / "src" / "main" / "resources" / "assets" / "sitandwatch"
TARGET_HEIGHT_PX = 16.0  # Keeps Perry close to the size of the original wolf entity.

# Each model element is mapped to a part. The parts use the matching Blockbench
# group pivot so head/legs/tail can animate without changing the UV layout.
ELEMENT_PARTS = {
    "body": "body",
    "upperbody1": "body",
    "head": "head",
    "snout": "head",
    "jaw": "head",
    "leftear": "head",
    "Rightear": "head",
    "tongue": "head",
    "tongue_tip": "head",
    "tail": "tail",
    "rightarm": "front_right_upper",
    "rightelbow": "front_right_lower",
    "leftarm": "front_left_upper",
    "eblow": "front_left_lower",
    "leg1": "rear_left_upper",
    "knee1": "rear_left_lower",
    "leg2": "rear_right_upper",
    "knee2": "rear_right_lower",
}

GROUP_PIVOTS = {
    "head": (4.0, 79.04, -48.0),
    "tail": (0.0, 88.0, 80.0),
    "front_right_upper": (12.0, 55.0, -32.0),
    "front_right_lower": (12.0, 26.0, -32.0),
    "front_left_upper": (-12.0, 57.0, -32.0),
    "front_left_lower": (-12.0, 26.0, -32.0),
    "rear_left_upper": (-12.0, 57.0, 56.0),
    "rear_left_lower": (-12.0, 26.6, 56.0),
    "rear_right_upper": (12.0, 56.2, 56.0),
    "rear_right_lower": (12.0, 26.6, 56.0),
    "body": (0.0, 0.0, 0.0),
}

def transform(v: tuple[float, float, float], scale: float, y_min: float) -> tuple[float, float, float]:
    # The Blockbench model's +Y points upward. Minecraft model space uses +Y down.
    return (-v[0] * scale, 24.0 - (v[1] - y_min) * scale, v[2] * scale)

def cube_face_vertices(x1, y1, z1, x2, y2, z2, direction):
    # Order is top-left, top-right, bottom-right, bottom-left as seen from
    # outside the face, matching Blockbench's per-face UV rectangle convention.
    return {
        "north": [(x2,y2,z1), (x1,y2,z1), (x1,y1,z1), (x2,y1,z1)],
        "south": [(x1,y2,z2), (x2,y2,z2), (x2,y1,z2), (x1,y1,z2)],
        "east":  [(x2,y2,z2), (x2,y2,z1), (x2,y1,z1), (x2,y1,z2)],
        "west":  [(x1,y2,z1), (x1,y2,z2), (x1,y1,z2), (x1,y1,z1)],
        "up":    [(x1,y2,z1), (x2,y2,z1), (x2,y2,z2), (x1,y2,z2)],
        "down":  [(x1,y1,z2), (x2,y1,z2), (x2,y1,z1), (x1,y1,z1)],
    }[direction]

def face_uv_corners(face):
    u1, v1, u2, v2 = map(float, face["uv"])
    corners = [(u1,v1), (u2,v1), (u2,v2), (u1,v2)]
    rotation = int(face.get("rotation", 0)) % 360
    if rotation not in (0, 90, 180, 270):
        raise ValueError(f"Unsupported Blockbench face rotation: {rotation}")
    # Clockwise image rotation: geometry's top-left samples the old bottom-left.
    shift = (rotation // 90)
    return corners[-shift:] + corners[:-shift] if shift else corners

def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )

def main() -> None:
    model = json.loads(SOURCE.read_text(encoding="utf-8"))
    resolution = model["resolution"]
    tex_w, tex_h = int(resolution["width"]), int(resolution["height"])
    elements = model["elements"]

    ys = [float(v) for element in elements for v in (element["from"][1], element["to"][1])]
    y_min, y_max = min(ys), max(ys)
    if y_max <= y_min:
        raise ValueError("Perry model has no vertical extent")
    scale = TARGET_HEIGHT_PX / (y_max - y_min)

    grouped = {}
    for element in elements:
        part_name = ELEMENT_PARTS.get(element["name"])
        if part_name is None:
            raise ValueError(f"Unmapped Perry model element: {element['name']}")
        x1, y1, z1 = map(float, element["from"])
        x2, y2, z2 = map(float, element["to"])
        triangles = grouped.setdefault(part_name, [])
        for direction, face in element.get("faces", {}).items():
            if face is None or face.get("texture") is None:
                continue
            corners = cube_face_vertices(x1, y1, z1, x2, y2, z2, direction)
            uvs = face_uv_corners(face)
            points = [(transform(point, scale, y_min), uv) for point, uv in zip(corners, uvs)]
            # Split the quad into two triangles while preserving corner-to-UV pairing.
            triangles.append([points[0], points[1], points[2]])
            triangles.append([points[0], points[2], points[3]])

    mesh_dir = ASSETS / "meshes"
    texture_dir = ASSETS / "textures" / "entity"
    mesh_dir.mkdir(parents=True, exist_ok=True)
    texture_dir.mkdir(parents=True, exist_ok=True)

    blob = bytearray(struct.pack(">i", len(grouped)))
    for part_name, triangles in grouped.items():
        if not triangles:
            continue
        pivot = transform(GROUP_PIVOTS[part_name], scale, y_min)
        positions = [[vertex[0] for vertex in triangle] for triangle in triangles]
        all_positions = [v for tri in positions for v in tri]
        center = tuple(sum(v[axis] for v in all_positions) / len(all_positions) for axis in range(3))

        raw_normals = []
        outward_score = 0.0
        for tri in positions:
            a, b, c = tri
            ab = tuple(b[i] - a[i] for i in range(3))
            ac = tuple(c[i] - a[i] for i in range(3))
            normal = cross(ab, ac)
            raw_normals.append(normal)
            centroid = tuple(sum(v[i] for v in tri) / 3.0 for i in range(3))
            outward_score += sum(normal[i] * (centroid[i] - center[i]) for i in range(3))
        winding = (0, 1, 2) if outward_score >= 0 else (0, 2, 1)
        sign = 1.0 if outward_score >= 0 else -1.0

        name_bytes = part_name.encode("utf-8")
        blob += struct.pack(">H", len(name_bytes)) + name_bytes
        blob += struct.pack(">fff", *pivot)
        blob += struct.pack(">i", len(triangles) * 3)

        for tri, normal in zip(triangles, raw_normals):
            length = math.sqrt(sum(component * component for component in normal)) or 1.0
            nx, ny, nz = (sign * component / length for component in normal)
            for index in winding:
                position, uv = tri[index]
                blob += struct.pack(
                    ">8f",
                    position[0], position[1], position[2],
                    uv[0] / tex_w, uv[1] / tex_h,
                    nx, ny, nz,
                )

    mesh_path = mesh_dir / "perry.bin"
    mesh_path.write_bytes(blob)

    texture = model["textures"][0]["source"]
    if texture.startswith("data:"):
        image = Image.open(BytesIO(base64.b64decode(texture.split(",", 1)[1])))
    else:
        image_path = (SOURCE.parent / texture).resolve()
        image = Image.open(image_path)
    image.convert("RGBA").save(texture_dir / "perry_wolf.png")

    print(f"Converted Perry: {len(grouped)} parts, {len(elements)} elements")
    print(f"Scale: {scale:.6f}; texture: {tex_w}x{tex_h}")
    print(f"Mesh: {mesh_path} ({len(blob):,} bytes)")

if __name__ == "__main__":
    main()
