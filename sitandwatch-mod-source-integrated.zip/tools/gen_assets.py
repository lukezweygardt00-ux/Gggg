import json,os
from PIL import Image
R='/home/claude/work/proj/src/main/resources/'
A=R+'assets/sitandwatch/'; D=R+'data/sitandwatch/'
def w(path,obj):
    os.makedirs(os.path.dirname(path),exist_ok=True)
    open(path,'w').write(json.dumps(obj,indent=2) if not isinstance(obj,str) else obj)
YROT={'north':0,'east':90,'south':180,'west':270}
def facing_states(model_fn):
    return {f'facing={f}':{'model':model_fn,'y':y} if y else {'model':model_fn} for f,y in YROT.items()}
# --- textures: open couch
from PIL import ImageDraw
import random; random.seed(3)
c=Image.open(A+'textures/block/couch.png').convert('RGBA'); d=ImageDraw.Draw(c)
d.rectangle((6,0,9,15),fill=(60,5,10,255)); d.rectangle((7,0,8,15),fill=(120,10,15,255)); c.save(A+'textures/block/couch_open.png')
# --- block models
def cube(name,north,other,up=None,down=None):
    w(A+f'models/block/{name}.json',{'parent':'minecraft:block/cube','textures':{
      'particle':other,'down':down or other,'up':up or other,'north':north,'south':other,'east':other,'west':other}})
cube('zipper_couch','sitandwatch:block/couch','sitandwatch:block/couch')
cube('zipper_couch_zip','sitandwatch:block/couch_zipper','sitandwatch:block/couch','sitandwatch:block/couch')
cube('zipper_couch_open','sitandwatch:block/couch_open','sitandwatch:block/couch')
cube('working_tv','sitandwatch:block/tv_screen','sitandwatch:block/tv_side')
cube('smug_statue','sitandwatch:block/smug_statue','sitandwatch:block/smug_statue_top','sitandwatch:block/smug_statue_top','sitandwatch:block/smug_statue_top')
# luxury bed (low)
w(A+'models/block/luxury_bed.json',{'textures':{'particle':'sitandwatch:block/luxury_bed','s':'sitandwatch:block/luxury_bed','t':'sitandwatch:block/luxury_bed_top'},
 'elements':[{'from':[0,0,0],'to':[16,9,16],'faces':{k:{'uv':[0,0,16,9] if k not in('up','down') else [0,0,16,16],'texture':'#t' if k=='up' else '#s','cullface':k} for k in['down','up','north','south','west','east']}}]})
# chair
def box(f,t,tex='#p'):
    return {'from':f,'to':t,'faces':{k:{'uv':[f[0],16-t[1],t[0],16-f[1]] if k not in('up','down') else [f[0],f[2],t[0],t[2]],'texture':tex} for k in['down','up','north','south','west','east']}}
w(A+'models/block/wooden_chair.json',{'textures':{'particle':'minecraft:block/oak_planks','p':'minecraft:block/oak_planks'},
 'elements':[box([3,7,3],[13,9,13]),box([3,0,3],[5,7,5]),box([11,0,3],[13,7,5]),box([3,0,11],[5,7,13]),box([11,0,11],[13,7,13]),box([3,9,11],[13,19,13])]})
# blockstates
for n,m in [('working_tv','working_tv'),('smug_statue','smug_statue'),('luxury_bed','luxury_bed'),('wooden_chair','wooden_chair')]:
    w(A+f'blockstates/{n}.json',{'variants':facing_states('sitandwatch:block/'+m)})
v={}
for f,y in YROT.items():
    for hz,un,mod in [('false','false','zipper_couch'),('true','false','zipper_couch_zip'),('true','true','zipper_couch_open')]:
        e={'model':'sitandwatch:block/'+mod}
        if y: e['y']=y
        v[f'facing={f},has_zipper={hz},unzipped={un}']=e
w(A+'blockstates/zipper_couch.json',{'variants':v})
# trapdoor (vanilla oak models)
v={}
for f,(y) in {'north':0,'east':90,'south':180,'west':270}.items():
    for half in['bottom','top']:
        for op in['false','true']:
            if op=='true': mdl='minecraft:block/oak_trapdoor_open'; x=0; yy={'north':0,'east':90,'south':180,'west':270}[f]
            else: mdl='minecraft:block/oak_trapdoor_'+half; yy=0
            e={'model':mdl}
            if half=='top' and op=='true': e['x']=180; yy=(yy+180)%360
            if op=='true' and half=='bottom': pass
            if op=='false' and half=='bottom': pass
            if yy: e['y']=yy
            v[f'facing={f},half={half},open={op},powered=false']=e
            v[f'facing={f},half={half},open={op},powered=true']=e
w(A+'blockstates/basement_trapdoor.json',{'variants':v})
# item models
for n in ['zipper_couch','working_tv','smug_statue','luxury_bed','wooden_chair']:
    w(A+f'models/item/{n}.json',{'parent':f'sitandwatch:block/{n}'})
w(A+'models/item/basement_trapdoor.json',{'parent':'minecraft:block/oak_trapdoor_bottom'})
for e in['smug_bro','ron_villager','perry_wolf','social_villager','the_watcher']:
    w(A+f'models/item/{e}_spawn_egg.json',{'parent':'minecraft:item/template_spawn_egg'})
# lang
w(A+'lang/en_us.json',{
 'itemGroup.sitandwatch':'Something Wants You To Sit And Watch',
 'block.sitandwatch.zipper_couch':'Couch','block.sitandwatch.working_tv':'Television','block.sitandwatch.smug_statue':'Smug Bro Statue',
 'block.sitandwatch.luxury_bed':'Luxury Bed','block.sitandwatch.wooden_chair':'Wooden Chair','block.sitandwatch.basement_trapdoor':'Trapdoor',
 'entity.sitandwatch.smug_bro':'Smug Bro','entity.sitandwatch.ron_villager':'Ron','entity.sitandwatch.perry_wolf':'Perry',
 'entity.sitandwatch.social_villager':'Villager','entity.sitandwatch.the_watcher':'The Watcher','entity.sitandwatch.chair_seat':'Seat',
 'item.sitandwatch.smug_bro_spawn_egg':'Smug Bro Spawn Egg','item.sitandwatch.ron_villager_spawn_egg':'Ron Spawn Egg',
 'item.sitandwatch.perry_wolf_spawn_egg':'Perry Spawn Egg','item.sitandwatch.social_villager_spawn_egg':'Villager Spawn Egg','item.sitandwatch.the_watcher_spawn_egg':'The Watcher Spawn Egg',
 'subtitles.sitandwatch.smug_bro_talk':'Smug Bro: §k#@%&$§r','subtitles.sitandwatch.smug_bro_hurt':'Smug Bro grunts','subtitles.sitandwatch.smug_bro_death':'Smug Bro fades',
 'subtitles.sitandwatch.obsessed_cheer':'Villagers cheer','subtitles.sitandwatch.watcher_breathing':'Heavy breathing','subtitles.sitandwatch.sit_in_the_chair':'The Watcher speaks',
 'subtitles.sitandwatch.zipper':'Zipper unzips','subtitles.sitandwatch.gore_burst':'Something bursts','subtitles.sitandwatch.ambience':'Ominous ambience','subtitles.sitandwatch.smug_theme':'Cheerful music',
 'sitandwatch.subtitle.sit':'Sit in the chair and watch.','sitandwatch.subtitle.continued':'TO BE CONTINUED?',
 'sitandwatch.message.cannot_sleep':'Something is outside. You cannot sleep.',
 'sitandwatch.message.released':'You can move again.'})
# sounds.json
def ev(sounds,sub,**kw):
    d={'sounds':sounds,'subtitle':'subtitles.sitandwatch.'+sub}; d.update(kw); return d
V='minecraft:mob/villager/'
w(A+'sounds.json',{
 'smug_bro_talk':ev([{'name':V+'idle1','pitch':0.5},{'name':V+'idle2','pitch':0.45},{'name':V+'idle3','pitch':0.55},{'name':V+'yes1','pitch':0.5},{'name':V+'no1','pitch':0.45}],'smug_bro_talk'),
 'smug_bro_hurt':ev([{'name':V+'hit1','pitch':0.5},{'name':V+'hit2','pitch':0.45}],'smug_bro_hurt'),
 'smug_bro_death':ev([{'name':V+'death','pitch':0.45}],'smug_bro_death'),
 'smug_theme':ev([{'name':'sitandwatch:smug_bro_theme','stream':True}],'smug_theme'),
 'obsessed_cheer':ev(['sitandwatch:obsessed_cheer'],'obsessed_cheer'),
 'sit_in_the_chair':ev(['sitandwatch:sit_in_the_chair'],'sit_in_the_chair'),
 'watcher_breathing':ev(['sitandwatch:watcher_breathing'],'watcher_breathing'),
 'zipper':ev(['sitandwatch:zipper'],'zipper'),
 'gore_burst':ev(['sitandwatch:gore_burst'],'gore_burst'),
 'ambience_loop':ev([{'name':'sitandwatch:ambience_loop','stream':True}],'ambience')})
# data: loot tables & recipe
for n in ['zipper_couch','working_tv','smug_statue','luxury_bed','wooden_chair','basement_trapdoor']:
    w(D+f'loot_tables/blocks/{n}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'sitandwatch:'+n}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
w(D+'recipes/zipper_couch.json',{'type':'minecraft:crafting_shaped','pattern':['WWW','WWW','P P'],'key':{'W':{'tag':'minecraft:wool'},'P':{'tag':'minecraft:planks'}},'result':{'item':'sitandwatch:zipper_couch'}})
w(D+'recipes/wooden_chair.json',{'type':'minecraft:crafting_shaped','pattern':['P  ','PPP','P P'],'key':{'P':{'tag':'minecraft:planks'}},'result':{'item':'sitandwatch:wooden_chair'}})
w(R+'pack.mcmeta',{'pack':{'description':'Something Wants You To Sit And Watch resources','pack_format':15}})
print('assets ok')
