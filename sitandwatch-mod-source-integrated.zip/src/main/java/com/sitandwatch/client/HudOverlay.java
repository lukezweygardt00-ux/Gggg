package com.sitandwatch.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.sitandwatch.SitAndWatch;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Story objective/minimap, subtitle and cinematic overlay. */
public class HudOverlay {
    private static final ResourceLocation BLOOD = new ResourceLocation(SitAndWatch.MOD_ID, "textures/gui/blood.png");
    private static final int BLOOD_W = 1024, BLOOD_H = 702;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientState.guideKey.isEmpty() && mc.player != null) {
            drawGuide(mc, g, w, h);
        }
        if (ClientState.bloodTicks > 0) {
            float f = Mth.clamp((ClientState.bloodTicks - partialTick) / (float) ClientState.bloodMax * 1.8f, 0f, 1f);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            g.setColor(1f, 1f, 1f, f * 0.92f);
            g.blit(BLOOD, 0, 0, w, h, 0, 0, BLOOD_W, BLOOD_H, BLOOD_W, BLOOD_H);
            g.setColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }
        if (ClientState.subTicks > 0 && !ClientState.subKey.isEmpty()) {
            float f = Mth.clamp(Math.min(ClientState.subTicks, ClientState.subMax - ClientState.subTicks + 10) / 10f, 0f, 1f);
            int alpha = Mth.clamp((int) (255 * f), 8, 255);
            Component text = Component.translatable(ClientState.subKey);
            var pose = g.pose();
            pose.pushPose();
            pose.translate(w / 2f, h * 0.70f, 0);
            pose.scale(2.0f, 2.0f, 1.0f);
            if (ClientState.subDistorted) {
                float t = mc.player != null ? mc.player.tickCount : 0;
                float j = Mth.sin(t * 1.7f) * 1.5f;
                g.drawCenteredString(mc.font, text, (int) j, 0, (alpha / 2 << 24) | 0xFF2020);
                g.drawCenteredString(mc.font, text, (int) -j, 1, (alpha / 2 << 24) | 0x20E0FF);
            }
            g.drawCenteredString(mc.font, text, 0, 0, (alpha << 24) | 0xFFFFFF);
            pose.popPose();
        }

        if (ClientState.basementDistortion) {
            drawBasementDistortion(mc, g, w, h);
        }

        float fade = ClientState.fadeAlpha();
        if (fade > 0.001f) {
            int alpha = Mth.clamp((int) (fade * 255.0f), 0, 255);
            g.fill(0, 0, w, h, alpha << 24);
        }
    }

    private static void drawGuide(Minecraft mc, GuiGraphics g, int screenWidth, int screenHeight) {
        // Minimal white objective text, centered just above the vanilla armor/health rows.
        Component objective = Component.translatable(ClientState.guideKey);
        int maxWidth = Math.max(120, Math.min(300, screenWidth - 40));
        var lines = mc.font.split(objective, maxWidth);
        int lineCount = Math.min(2, lines.size());
        int textY = screenHeight - 61 - (lineCount - 1) * 10;
        for (int i = 0; i < lineCount; i++) {
            var line = lines.get(i);
            g.drawString(mc.font, line, (screenWidth - mc.font.width(line)) / 2,
                    textY + i * 10, 0xFFFFFFFF, false);
        }

        // Keep the terrain minimap, but make it small and unobtrusive.
        if (!ClientState.mapReady) ClientState.refreshMinimap(mc);
        final int cell = 2;
        final int mapPixels = ClientState.MAP_SIZE * cell;
        final int mapX = screenWidth - mapPixels - 8;
        final int mapY = 8;
        g.fill(mapX - 2, mapY - 2, mapX + mapPixels + 2, mapY + mapPixels + 2, 0x50000000);
        for (int z = 0; z < ClientState.MAP_SIZE; z++) {
            for (int x = 0; x < ClientState.MAP_SIZE; x++) {
                int color = ClientState.mapPixels[z * ClientState.MAP_SIZE + x];
                int px = mapX + x * cell, py = mapY + z * cell;
                g.fill(px, py, px + cell, py + cell, color);
            }
        }
        int playerX = mapX + ClientState.MAP_RADIUS * cell;
        int playerY = mapY + ClientState.MAP_RADIUS * cell;
        g.fill(playerX - 1, playerY - 1, playerX + 2, playerY + 2, 0xFFFFFFFF);
        if (ClientState.guideHasTarget) {
            int dx = ClientState.guideX - ClientState.mapCenterX;
            int dz = ClientState.guideZ - ClientState.mapCenterZ;
            int mx = mapX + (ClientState.MAP_RADIUS + Math.max(-ClientState.MAP_RADIUS, Math.min(ClientState.MAP_RADIUS, dx))) * cell;
            int mz = mapY + (ClientState.MAP_RADIUS + Math.max(-ClientState.MAP_RADIUS, Math.min(ClientState.MAP_RADIUS, dz))) * cell;
            g.fill(mx - 1, mz - 1, mx + 2, mz + 2, 0xFFFFD34F);
        }
    }

    /** A restrained dark ripple/vignette used near the mansion's sealed basement. */
    private static void drawBasementDistortion(Minecraft mc, GuiGraphics g, int w, int h) {
        g.fill(0, 0, w, h, 0x26040710);
        int edge = Math.max(18, Math.min(w, h) / 12);
        for (int i = 0; i < edge; i += 4) {
            int alpha = Math.max(3, 22 - i / 3);
            int color = (alpha << 24) | 0x02030A;
            g.fill(i, 0, i + 4, h, color);
            g.fill(w - i - 4, 0, w - i, h, color);
        }
        int tick = mc.player != null ? mc.player.tickCount : 0;
        for (int i = 0; i < 5; i++) {
            int y = Math.floorMod(tick * 3 + i * 47, Math.max(1, h));
            g.fill(0, y, w, y + 1, 0x100E1525);
        }
    }
}
