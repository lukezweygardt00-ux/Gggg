package com.sitandwatch.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.sitandwatch.entity.PerryEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/** Blockbench mesh model for Perry, with a four-legged walk cycle and head/tail movement. */
public class PerryMeshModel extends EntityModel<PerryEntity> {
    private float headYaw;
    private float headPitch;
    private float walkPhase;
    private float walkAmount;
    private float age;

    public PerryMeshModel() {
        super(RenderType::entityCutoutNoCull);
    }

    @Override
    public void setupAnim(PerryEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.walkPhase = limbSwing * 0.6662f;
        this.walkAmount = Mth.clamp(limbSwingAmount, 0.0f, 1.0f);
        this.age = ageInTicks;
        this.headYaw = netHeadYaw * Mth.DEG_TO_RAD;
        this.headPitch = headPitch * Mth.DEG_TO_RAD;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        MeshData data = MeshData.get("perry");
        for (MeshData.Part part : data.parts) {
            float rotX = 0.0f;
            float rotY = 0.0f;
            float rotZ = 0.0f;

            switch (part.name) {
                case "head" -> {
                    rotX = headPitch;
                    rotY = headYaw;
                }
                case "tail" -> {
                    // Perry's tail wags more quickly while trotting, with a small counter-sway.
                    rotY = Mth.sin(age * (0.12f + walkAmount * 0.035f)) * (0.12f + walkAmount * 0.12f);
                    rotX = Mth.sin(age * 0.08f) * 0.04f;
                }
                case "body" -> {
                    // A light breathing pulse and an alternating trot roll keep the mesh alive.
                    rotX = Mth.sin(age * 0.12f) * 0.012f;
                    rotZ = Mth.sin(walkPhase * 0.5f) * 0.045f * walkAmount;
                }
                case "front_right_upper", "rear_left_upper" -> {
                    rotX = Mth.cos(walkPhase) * 0.85f * walkAmount;
                }
                case "front_left_upper", "rear_right_upper" -> {
                    rotX = Mth.cos(walkPhase + Mth.PI) * 0.85f * walkAmount;
                }
                case "front_right_lower", "rear_left_lower" -> {
                    rotX = Math.max(0.0f, -Mth.cos(walkPhase)) * 0.30f * walkAmount;
                }
                case "front_left_lower", "rear_right_lower" -> {
                    rotX = Math.max(0.0f, -Mth.cos(walkPhase + Mth.PI)) * 0.30f * walkAmount;
                }
                default -> {
                    // Body remains rigid so the custom mesh keeps its original silhouette.
                }
            }

            poseStack.pushPose();
            poseStack.translate(part.px, part.py, part.pz);
            if (rotX != 0.0f || rotY != 0.0f || rotZ != 0.0f) {
                poseStack.mulPose(new Quaternionf().rotationZYX(rotZ, rotY, rotX));
            }
            poseStack.translate(-part.px, -part.py, -part.pz);

            PoseStack.Pose last = poseStack.last();
            Matrix4f matrix = last.pose();
            Matrix3f normalMatrix = last.normal();
            float[] vertices = part.v;

            // MeshData stores triangles; emit a degenerate quad for Minecraft's QUADS render type.
            for (int i = 0; i + 2 < part.count; i += 3) {
                emit(consumer, matrix, normalMatrix, vertices, i * 8,
                        packedLight, packedOverlay, red, green, blue, alpha);
                emit(consumer, matrix, normalMatrix, vertices, (i + 1) * 8,
                        packedLight, packedOverlay, red, green, blue, alpha);
                emit(consumer, matrix, normalMatrix, vertices, (i + 2) * 8,
                        packedLight, packedOverlay, red, green, blue, alpha);
                emit(consumer, matrix, normalMatrix, vertices, (i + 2) * 8,
                        packedLight, packedOverlay, red, green, blue, alpha);
            }
            poseStack.popPose();
        }
    }

    private static void emit(VertexConsumer consumer, Matrix4f matrix, Matrix3f normalMatrix,
                             float[] vertices, int offset, int packedLight, int packedOverlay,
                             float red, float green, float blue, float alpha) {
        consumer.vertex(matrix, vertices[offset], vertices[offset + 1], vertices[offset + 2])
                .color(red, green, blue, alpha)
                .uv(vertices[offset + 3], vertices[offset + 4])
                .overlayCoords(packedOverlay)
                .uv2(packedLight)
                .normal(normalMatrix, vertices[offset + 5], vertices[offset + 6], vertices[offset + 7])
                .endVertex();
    }
}
