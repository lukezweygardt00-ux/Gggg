package com.sitandwatch.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Non-positional looping sound that fades in/out; used for Smug Bro's theme and the basement ambience. */
public class LoopingSound extends AbstractTickableSoundInstance {
    private final BooleanSupplier active;
    private final Supplier<Float> targetVolume;

    public LoopingSound(SoundEvent event, SoundSource source, BooleanSupplier active, Supplier<Float> targetVolume) {
        super(event, source, SoundInstance.createUnseededRandom());
        this.active = active;
        this.targetVolume = targetVolume;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.001f;
        this.relative = true;
        this.attenuation = SoundInstance.Attenuation.NONE;
    }

    @Override
    public void tick() {
        float target = targetVolume.get();
        if (!active.getAsBoolean()) {
            this.volume -= 0.03f;
            if (this.volume <= 0.0f) {
                this.volume = 0.0f;
                this.stop();
            }
            return;
        }
        if (this.volume < target) this.volume = Math.min(target, this.volume + 0.02f);
        else this.volume = Math.max(target, this.volume - 0.02f);
    }
}
