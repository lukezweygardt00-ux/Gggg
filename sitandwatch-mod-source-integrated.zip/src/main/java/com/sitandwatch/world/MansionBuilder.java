package com.sitandwatch.world;

import com.sitandwatch.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.block.state.properties.StairsShape;

/** Builds Smug Bro's furnished mansion and the detailed, story-locked basement. */
public class MansionBuilder {
    public static final int W = 17;
    public static final int D = 13;
    private static final int FLAGS = 2;
    // Server-thread-only filter used to emit one vertical slice of the mansion per call.
    private static int activeLayerY = Integer.MIN_VALUE;

    private static void set(ServerLevel level, BlockPos origin, int x, int y, int z, BlockState state) {
        int worldY = origin.getY() + y;
        if (activeLayerY == Integer.MIN_VALUE || activeLayerY == worldY) {
            level.setBlock(origin.offset(x, y, z), state, FLAGS);
        }
    }

    private static void fill(ServerLevel level, BlockPos origin, int x0, int y0, int z0,
                             int x1, int y1, int z1, BlockState state) {
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) set(level, origin, x, y, z, state);
            }
        }
    }

    /** Builds the complete mansion in one call (also used for legacy save repair). */
    public static void build(ServerLevel level, StoryData data, BlockPos origin) {
        int previous = activeLayerY;
        activeLayerY = Integer.MIN_VALUE;
        try { buildInternal(level, data, origin); } finally { activeLayerY = previous; }
    }

    /** Builds one vertical layer at the supplied local Y coordinate. */
    public static void buildLayer(ServerLevel level, StoryData data, BlockPos origin, int localY) {
        int previous = activeLayerY;
        activeLayerY = origin.getY() + localY;
        try { buildInternal(level, data, origin); } finally { activeLayerY = previous; }
    }

    /** origin is the north-west ground-floor corner; its y coordinate is the ground-floor air level. */
    private static void buildInternal(ServerLevel level, StoryData data, BlockPos origin) {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState birch = Blocks.BIRCH_PLANKS.defaultBlockState();
        BlockState darkOak = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        BlockState strippedBirch = Blocks.STRIPPED_BIRCH_LOG.defaultBlockState();
        BlockState gold = Blocks.GOLD_BLOCK.defaultBlockState();
        BlockState stoneBrick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState glass = Blocks.GLASS.defaultBlockState();

        // Clear the building volume and form the foundation and basement shell.
        fill(level, origin, -3, 0, -3, W + 2, 14, D + 5, air);
        fill(level, origin, 0, -8, 0, W - 1, -1, D - 1, stoneBrick);
        fill(level, origin, 0, -1, 0, W - 1, -1, D - 1, birch);

        // Basement: sturdy stone-brick walls, a timber floor and a narrow ladder entrance.
        fill(level, origin, 2, -7, 1, 14, -2, 11, stoneBrick);
        fill(level, origin, 3, -6, 2, 13, -3, 10, air);
        fill(level, origin, 3, -7, 2, 13, -7, 10, darkOak);
        for (int y = -6; y <= -2; y++) {
            set(level, origin, 13, y, 2,
                    Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH));
        }
        set(level, origin, 13, -1, 2, ModBlocks.BASEMENT_TRAPDOOR.get().defaultBlockState()
                .setValue(TrapDoorBlock.FACING, Direction.NORTH)
                .setValue(TrapDoorBlock.HALF, Half.BOTTOM)
                .setValue(TrapDoorBlock.OPEN, false));

        // The Watcher's room: chair, Ron's cot, and small environmental details.
        set(level, origin, 8, -6, 6, ModBlocks.WOODEN_CHAIR.get().defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH));
        fill(level, origin, 7, -6, 3, 9, -6, 3, Blocks.WHITE_WOOL.defaultBlockState());
        set(level, origin, 6, -6, 3, Blocks.BIRCH_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM));
        set(level, origin, 10, -6, 3, Blocks.BARREL.defaultBlockState());
        set(level, origin, 4, -6, 3, Blocks.CHEST.defaultBlockState());
        set(level, origin, 4, -6, 4, Blocks.BOOKSHELF.defaultBlockState());
        set(level, origin, 11, -6, 8, Blocks.CAULDRON.defaultBlockState());
        set(level, origin, 12, -6, 8, Blocks.BARREL.defaultBlockState());
        set(level, origin, 6, -6, 8, Blocks.REDSTONE_TORCH.defaultBlockState());
        set(level, origin, 3, -4, 3, Blocks.SOUL_LANTERN.defaultBlockState());
        set(level, origin, 12, -4, 9, Blocks.SOUL_LANTERN.defaultBlockState());
        set(level, origin, 5, -5, 10, Blocks.IRON_BARS.defaultBlockState());
        set(level, origin, 6, -5, 10, Blocks.IRON_BARS.defaultBlockState());
        set(level, origin, 7, -5, 10, Blocks.IRON_BARS.defaultBlockState());
        set(level, origin, 10, -5, 2, Blocks.COBWEB.defaultBlockState());
        set(level, origin, 5, -5, 2, Blocks.COBWEB.defaultBlockState());
        set(level, origin, 9, -6, 9, Blocks.DARK_OAK_FENCE.defaultBlockState());
        set(level, origin, 9, -5, 9, Blocks.STONE_PRESSURE_PLATE.defaultBlockState());
        set(level, origin, 3, -6, 5, Blocks.REDSTONE_TORCH.defaultBlockState());
        set(level, origin, 13, -6, 5, Blocks.REDSTONE_TORCH.defaultBlockState());

        // Ground-floor walls, windows and structural timber.
        for (int y = 0; y <= 4; y++) {
            for (int x = 0; x < W; x++) {
                set(level, origin, x, y, 0, birch);
                set(level, origin, x, y, D - 1, birch);
            }
            for (int z = 0; z < D; z++) {
                set(level, origin, 0, y, z, birch);
                set(level, origin, W - 1, y, z, birch);
            }
        }
        for (int y = 0; y <= 9; y++) {
            for (int x : new int[]{0, W - 1}) {
                for (int z : new int[]{0, D - 1}) set(level, origin, x, y, z, strippedBirch);
            }
        }

        // Second floor and its clear stair opening.
        fill(level, origin, 0, 5, 0, W - 1, 5, D - 1, birch);
        fill(level, origin, 2, 5, 3, 2, 5, 8, air);
        for (int y = 6; y <= 9; y++) {
            for (int x = 0; x < W; x++) {
                set(level, origin, x, y, 0, birch);
                set(level, origin, x, y, D - 1, birch);
            }
            for (int z = 0; z < D; z++) {
                set(level, origin, 0, y, z, birch);
                set(level, origin, W - 1, y, z, birch);
            }
        }
        for (int y = 0; y <= 9; y++) {
            for (int x : new int[]{0, W - 1}) {
                for (int z : new int[]{0, D - 1}) set(level, origin, x, y, z, strippedBirch);
            }
        }

        for (int floor : new int[]{1, 7}) {
            for (int x : new int[]{3, 5, 11, 13}) {
                set(level, origin, x, floor, 0, glass);
                set(level, origin, x, floor + 1, 0, glass);
                set(level, origin, x, floor, D - 1, glass);
                set(level, origin, x, floor + 1, D - 1, glass);
            }
            for (int z : new int[]{3, 6, 9}) {
                set(level, origin, 0, floor, z, glass);
                set(level, origin, 0, floor + 1, z, glass);
                set(level, origin, W - 1, floor, z, glass);
                set(level, origin, W - 1, floor + 1, z, glass);
            }
        }

        // Luxury exterior: framed facade columns, broad sills, balcony rails and a grand entry.
        BlockState quartz = Blocks.QUARTZ_PILLAR.defaultBlockState();
        BlockState polished = Blocks.POLISHED_DIORITE.defaultBlockState();
        BlockState goldTrim = Blocks.GOLD_BLOCK.defaultBlockState();
        for (int y = 0; y <= 9; y++) {
            for (int x : new int[]{2, W - 3, 8}) {
                if (x == 8 && y > 4) continue;
                set(level, origin, x, y, D - 1, quartz);
            }
            for (int z : new int[]{2, D - 3}) {
                set(level, origin, 0, y, z, polished);
                set(level, origin, W - 1, y, z, polished);
            }
        }
        for (int x = 1; x < W - 1; x++) {
            set(level, origin, x, 4, D - 1, polished);
            set(level, origin, x, 9, D - 1, polished);
            set(level, origin, x, 4, 0, polished);
            set(level, origin, x, 9, 0, polished);
        }
        // Second-storey front balcony with a continuous walkable slab and fence rail.
        for (int x = 2; x <= 14; x++) {
            set(level, origin, x, 6, D, Blocks.QUARTZ_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM));
            set(level, origin, x, 7, D, Blocks.IRON_BARS.defaultBlockState());
            set(level, origin, x, 6, -1, Blocks.QUARTZ_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM));
            set(level, origin, x, 7, -1, Blocks.IRON_BARS.defaultBlockState());
        }
        for (int x : new int[]{2, 14}) {
            set(level, origin, x, 7, D, Blocks.QUARTZ_PILLAR.defaultBlockState());
            set(level, origin, x, 7, -1, Blocks.QUARTZ_PILLAR.defaultBlockState());
            set(level, origin, x, 2, D + 2, Blocks.LANTERN.defaultBlockState());
        }
        // Gold inlay and stone steps make the front entrance read as a mansion.
        for (int x : new int[]{4, 12}) set(level, origin, x, 3, D - 1, goldTrim);
        for (int z = D + 1; z <= D + 3; z++) {
            for (int x = 7; x <= 9; x++) {
                set(level, origin, x, -1, z, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
        // Symmetrical front gardens, clipped hedges, flower beds and illuminated stone posts.
        for (int side : new int[]{-1, 1}) {
            int gardenX = side < 0 ? 2 : 14;
            for (int z = D + 1; z <= D + 3; z++) {
                set(level, origin, gardenX, -1, z, Blocks.POLISHED_ANDESITE.defaultBlockState());
                set(level, origin, gardenX, 0, z, Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true));
            }
            set(level, origin, gardenX + (side < 0 ? -1 : 1), -1, D + 2, Blocks.DIRT.defaultBlockState());
            set(level, origin, gardenX + (side < 0 ? -1 : 1), 0, D + 2,
                    (side < 0 ? Blocks.POPPY : Blocks.BLUE_ORCHID).defaultBlockState());
            int postX = side < 0 ? 1 : W - 2;
            set(level, origin, postX, -1, D + 2, Blocks.QUARTZ_BLOCK.defaultBlockState());
            set(level, origin, postX, 0, D + 2, Blocks.QUARTZ_PILLAR.defaultBlockState());
            set(level, origin, postX, 1, D + 2, Blocks.LANTERN.defaultBlockState());
        }
        for (int x : new int[]{1, W - 2}) {
            set(level, origin, x, 10, D / 2, Blocks.GOLD_BLOCK.defaultBlockState());
        }

        // The staircase is one continuous, bottom-half run. The sixth step reaches
        // the upstairs floor height, and its block occupies the opening in that floor.
        BlockState stair = Blocks.OAK_STAIRS.defaultBlockState()
                .setValue(StairBlock.FACING, Direction.SOUTH)
                .setValue(StairBlock.HALF, Half.BOTTOM)
                .setValue(StairBlock.SHAPE, StairsShape.STRAIGHT);
        for (int i = 0; i < 6; i++) set(level, origin, 2, i, 3 + i, stair);

        // Roof, front entry and porch.
        for (int x = -1; x <= W; x++) {
            for (int z = -1; z <= D; z++) {
                set(level, origin, x, 10, z,
                        Blocks.DARK_OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM));
            }
        }
        fill(level, origin, 0, 10, 0, W - 1, 10, D - 1, darkOak);
        placeDoor(level, origin, 8, D - 1);
        for (int x : new int[]{5, 11}) {
            fill(level, origin, x, 0, D + 1, x, 3, D + 1, gold);
            set(level, origin, x, 4, D + 1, Blocks.GOLD_BLOCK.defaultBlockState());
        }
        fill(level, origin, 6, 4, D + 1, 10, 4, D + 1, gold);
        for (int z = D; z <= D + 4; z++) set(level, origin, 8, -1, z, Blocks.RED_CARPET.defaultBlockState());

        // Ground-floor lounge: sofa, coffee table, rug, bookshelves and a small kitchen corner.
        set(level, origin, 8, 0, 1, ModBlocks.WORKING_TV.get().defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH));
        BlockState sofa = Blocks.DARK_OAK_STAIRS.defaultBlockState()
                .setValue(StairBlock.FACING, Direction.NORTH)
                .setValue(StairBlock.HALF, Half.BOTTOM);
        for (int x = 5; x <= 7; x++) set(level, origin, x, 0, 4, sofa);
        for (int x = 9; x <= 11; x++) set(level, origin, x, 0, 4, sofa);
        fill(level, origin, 6, 0, 6, 10, 0, 8, Blocks.RED_CARPET.defaultBlockState());
        set(level, origin, 8, 0, 6, Blocks.DARK_OAK_FENCE.defaultBlockState());
        set(level, origin, 8, 1, 6, Blocks.DARK_OAK_PRESSURE_PLATE.defaultBlockState());
        // Keep the stairwell clear; these shelves sit against the opposite wall.
        set(level, origin, 14, 0, 2, Blocks.BOOKSHELF.defaultBlockState());
        set(level, origin, 14, 0, 3, Blocks.BOOKSHELF.defaultBlockState());
        set(level, origin, 14, 0, 8, Blocks.BARREL.defaultBlockState());
        set(level, origin, 14, 0, 9, Blocks.CAULDRON.defaultBlockState());
        set(level, origin, 13, 0, 9, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(level, origin, 3, 0, 10, Blocks.POTTED_DANDELION.defaultBlockState());
        set(level, origin, 13, 0, 10, Blocks.POTTED_OAK_SAPLING.defaultBlockState());
        set(level, origin, 3, 2, 1, Blocks.LANTERN.defaultBlockState());
        set(level, origin, 13, 2, 1, Blocks.LANTERN.defaultBlockState());
        set(level, origin, 3, 2, 11, Blocks.LANTERN.defaultBlockState());
        set(level, origin, 13, 2, 11, Blocks.LANTERN.defaultBlockState());
        set(level, origin, 8, 3, 6, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));

        // Upstairs: Smug Bro's bedroom, private office and trophy wall.
        BlockState luxuryMattress = ModBlocks.LUXURY_BED.get().defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.WEST);
        // Four connected mattress blocks make the bedroom bed a proper 2x2 luxury bed.
        for (int x = 12; x <= 13; x++) for (int z = 4; z <= 5; z++) {
            set(level, origin, x, 6, z, luxuryMattress);
        }
        for (int z = 4; z <= 5; z++) {
            set(level, origin, 14, 6, z, Blocks.WHITE_CARPET.defaultBlockState());
        }
        fill(level, origin, 5, 6, 2, 11, 6, 9, Blocks.RED_CARPET.defaultBlockState());
        set(level, origin, 4, 6, 2, Blocks.BOOKSHELF.defaultBlockState());
        set(level, origin, 4, 6, 3, Blocks.BOOKSHELF.defaultBlockState());
        set(level, origin, 4, 6, 4, Blocks.BOOKSHELF.defaultBlockState());
        set(level, origin, 12, 6, 8, Blocks.CHEST.defaultBlockState());
        set(level, origin, 11, 6, 8, Blocks.BARREL.defaultBlockState());
        set(level, origin, 10, 6, 8, Blocks.ENCHANTING_TABLE.defaultBlockState());
        set(level, origin, 5, 6, 8, Blocks.DARK_OAK_PLANKS.defaultBlockState());
        set(level, origin, 5, 7, 8, Blocks.DARK_OAK_PRESSURE_PLATE.defaultBlockState());
        set(level, origin, 3, 6, 9, Blocks.POTTED_RED_TULIP.defaultBlockState());
        set(level, origin, 14, 6, 9, Blocks.POTTED_BLUE_ORCHID.defaultBlockState());
        set(level, origin, 4, 8, 1, Blocks.LANTERN.defaultBlockState());
        set(level, origin, 12, 8, 11, Blocks.LANTERN.defaultBlockState());
        for (int x : new int[]{4, 12}) set(level, origin, x, 6, 1, ModBlocks.SMUG_STATUE.get().defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH));

        // Small gold accents and ceiling lights make the mansion feel lived-in rather than empty.
        for (int x : new int[]{3, 8, 13}) {
            set(level, origin, x, 4, 6, Blocks.CHAIN.defaultBlockState());
            set(level, origin, x, 3, 6, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        }

        // Save the story landmarks.
        data.site = origin;
        data.doorPos = origin.offset(8, 0, D - 1);
        data.partyPos = origin.offset(8, 0, D + 4);
        data.trapdoor = origin.offset(13, -1, 2);
        data.chair = origin.offset(8, -6, 6);
        data.ronSpot = origin.offset(8, -5, 3);
        data.smugRoom = origin.offset(8, 6, 6);
        data.basementMin = origin.offset(3, -6, 2);
        data.basementMax = origin.offset(13, -2, 10);
        data.mansionBuilt = activeLayerY == Integer.MIN_VALUE || activeLayerY == origin.getY() + 14;
        data.setDirty();
    }

    private static void placeDoor(ServerLevel level, BlockPos origin, int x, int z) {
        BlockState door = Blocks.BIRCH_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.SOUTH);
        set(level, origin, x, 0, z, door.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        set(level, origin, x, 1, z, door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
        set(level, origin, x, 2, z, Blocks.BIRCH_PLANKS.defaultBlockState());
    }
}
