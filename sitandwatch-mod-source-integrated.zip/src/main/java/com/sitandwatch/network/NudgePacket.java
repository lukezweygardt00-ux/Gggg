package com.sitandwatch.network;

import com.sitandwatch.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Smug Bro grabbing the player's shoulder: a brief camera nudge. */
public class NudgePacket {
    public final float dYaw, dPitch;

    public NudgePacket(float dYaw, float dPitch) { this.dYaw = dYaw; this.dPitch = dPitch; }

    public static void encode(NudgePacket m, FriendlyByteBuf b) { b.writeFloat(m.dYaw); b.writeFloat(m.dPitch); }

    public static NudgePacket decode(FriendlyByteBuf b) { return new NudgePacket(b.readFloat(), b.readFloat()); }

    public static void handle(NudgePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.nudge(m.dYaw, m.dPitch)));
        ctx.get().setPacketHandled(true);
    }
}
