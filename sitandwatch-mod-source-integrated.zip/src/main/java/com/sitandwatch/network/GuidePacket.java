package com.sitandwatch.network;

import com.sitandwatch.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sends the current story objective and its world-coordinate minimap marker. */
public class GuidePacket {
    public final String key;
    public final int x, z;
    public final boolean hasTarget;

    public GuidePacket(String key, int x, int z, boolean hasTarget) {
        this.key = key == null ? "" : key;
        this.x = x;
        this.z = z;
        this.hasTarget = hasTarget;
    }

    public static void encode(GuidePacket m, FriendlyByteBuf b) {
        b.writeUtf(m.key, 128);
        b.writeInt(m.x);
        b.writeInt(m.z);
        b.writeBoolean(m.hasTarget);
    }

    public static GuidePacket decode(FriendlyByteBuf b) {
        return new GuidePacket(b.readUtf(128), b.readInt(), b.readInt(), b.readBoolean());
    }

    public static void handle(GuidePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientState.setGuide(m.key, m.x, m.z, m.hasTarget)));
        ctx.get().setPacketHandled(true);
    }
}
