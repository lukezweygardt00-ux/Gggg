package com.sitandwatch.network;

import com.sitandwatch.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Freezes (or releases) the player's mouse-look and movement on the client. */
public class CameraLockPacket {
    public final boolean locked;
    public final float yaw, pitch;

    public CameraLockPacket(boolean locked, float yaw, float pitch) {
        this.locked = locked; this.yaw = yaw; this.pitch = pitch;
    }

    public static void encode(CameraLockPacket m, FriendlyByteBuf b) {
        b.writeBoolean(m.locked); b.writeFloat(m.yaw); b.writeFloat(m.pitch);
    }

    public static CameraLockPacket decode(FriendlyByteBuf b) {
        return new CameraLockPacket(b.readBoolean(), b.readFloat(), b.readFloat());
    }

    public static void handle(CameraLockPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.setLock(m.locked, m.yaw, m.pitch)));
        ctx.get().setPacketHandled(true);
    }
}
