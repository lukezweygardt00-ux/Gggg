package com.sitandwatch.event;

import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.StoryVillager;
import com.sitandwatch.registry.ModEntities;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SitAndWatch.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.SMUG_BRO.get(), StoryVillager.createAttributes().build());
        e.put(ModEntities.RON.get(), StoryVillager.createAttributes().build());
        e.put(ModEntities.SOCIAL_VILLAGER.get(), StoryVillager.createAttributes().build());
        e.put(ModEntities.WATCHER.get(), StoryVillager.createAttributes().build());
        e.put(ModEntities.PERRY.get(), Wolf.createAttributes().build());
    }
}
