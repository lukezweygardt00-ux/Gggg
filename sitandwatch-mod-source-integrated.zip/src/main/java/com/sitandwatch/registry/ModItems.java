package com.sitandwatch.registry;

import com.sitandwatch.SitAndWatch;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SitAndWatch.MOD_ID);

    private static RegistryObject<Item> blockItem(String n, RegistryObject<? extends net.minecraft.world.level.block.Block> b) {
        return ITEMS.register(n, () -> new BlockItem(b.get(), new Item.Properties()));
    }

    public static final RegistryObject<Item> ZIPPER_COUCH = blockItem("zipper_couch", ModBlocks.ZIPPER_COUCH);
    public static final RegistryObject<Item> WORKING_TV = blockItem("working_tv", ModBlocks.WORKING_TV);
    public static final RegistryObject<Item> SMUG_STATUE = blockItem("smug_statue", ModBlocks.SMUG_STATUE);
    public static final RegistryObject<Item> LUXURY_BED = blockItem("luxury_bed", ModBlocks.LUXURY_BED);
    public static final RegistryObject<Item> WOODEN_CHAIR = blockItem("wooden_chair", ModBlocks.WOODEN_CHAIR);
    public static final RegistryObject<Item> BASEMENT_TRAPDOOR = blockItem("basement_trapdoor", ModBlocks.BASEMENT_TRAPDOOR);

    public static final RegistryObject<Item> SMUG_EGG = ITEMS.register("smug_bro_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SMUG_BRO, 0x6b4a3a, 0xe0b090, new Item.Properties()));
    public static final RegistryObject<Item> RON_EGG = ITEMS.register("ron_villager_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.RON, 0x6b4a3a, 0x4fa0d0, new Item.Properties()));
    public static final RegistryObject<Item> PERRY_EGG = ITEMS.register("perry_wolf_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.PERRY, 0xdddddd, 0xaa0000, new Item.Properties()));
    public static final RegistryObject<Item> SOCIAL_EGG = ITEMS.register("social_villager_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SOCIAL_VILLAGER, 0x6b4a3a, 0xd0a060, new Item.Properties()));
    public static final RegistryObject<Item> WATCHER_EGG = ITEMS.register("the_watcher_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WATCHER, 0x000000, 0xffffff, new Item.Properties()));
}
