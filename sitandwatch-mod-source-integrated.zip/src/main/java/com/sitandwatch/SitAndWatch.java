package com.sitandwatch;

import com.sitandwatch.event.ForgeEvents;
import com.sitandwatch.network.ModNetwork;
import com.sitandwatch.registry.*;
import com.sitandwatch.world.StoryManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SitAndWatch.MOD_ID)
public class SitAndWatch {
    public static final String MOD_ID = "sitandwatch";

    public SitAndWatch() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(new ForgeEvents());
        MinecraftForge.EVENT_BUS.register(new StoryManager());
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
