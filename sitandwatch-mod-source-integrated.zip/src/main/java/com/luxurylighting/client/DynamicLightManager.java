package com.luxurylighting.client;

import com.sitandwatch.SitAndWatch;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Dynamic item lighting ported into Sit and Watch from the author's LuxuryLighting mod.
 * Held and dropped light-emitting block-items contribute local block light on the client.
 */
@Mod.EventBusSubscriber(modid = SitAndWatch.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DynamicLightManager {
    private static final double SCAN_RADIUS_SQUARED = 48.0D * 48.0D;
    private static volatile Source[] active = new Source[0];
    private static final Map<Integer, CachedSource> last = new HashMap<>();

    private DynamicLightManager() {}

    public static int emission(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return 0;
        if (stack.getItem() instanceof BlockItem blockItem) {
            return blockItem.getBlock().defaultBlockState().getLightEmission();
        }
        return 0;
    }

    public static int levelAt(BlockPos pos) {
        Source[] snapshot = active;
        if (snapshot.length == 0) return 0;

        double px = pos.getX() + 0.5D;
        double py = pos.getY() + 0.5D;
        double pz = pos.getZ() + 0.5D;
        int best = 0;

        for (Source source : snapshot) {
            double dx = px - source.x;
            double dy = py - source.y;
            double dz = pz - source.z;
            int remaining = source.level - (int) Math.floor(Math.sqrt(dx * dx + dy * dy + dz * dz));
            if (remaining > best) best = remaining;
        }
        return best;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        try {
            tick();
        } catch (Throwable ignored) {
            active = new Source[0];
        }
    }

    private static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        LocalPlayer player = minecraft.player;
        if (level == null || player == null) {
            active = new Source[0];
            for (Map.Entry<Integer, CachedSource> entry : last.entrySet()) {
                CachedSource old = entry.getValue();
                dirty(BlockPos.of(old.packedPos), old.level);
            }
            last.clear();
            return;
        }

        List<Source> next = new ArrayList<>();
        Set<Integer> seen = new HashSet<>();

        for (Entity entity : level.entitiesForRendering()) {
            if (entity.distanceToSqr(player) > SCAN_RADIUS_SQUARED) continue;

            int light = 0;
            if (entity instanceof ItemEntity itemEntity) {
                light = emission(itemEntity.getItem());
            } else if (entity instanceof LivingEntity living) {
                light = Math.max(emission(living.getMainHandItem()), emission(living.getOffhandItem()));
            }
            if (light <= 0) continue;

            Source source = new Source(entity.getX(), entity.getY() + entity.getBbHeight() * 0.6D,
                    entity.getZ(), light);
            next.add(source);

            int id = entity.getId();
            seen.add(id);
            BlockPos sourceBlock = BlockPos.containing(source.x, source.y, source.z);
            long packed = sourceBlock.asLong();
            CachedSource old = last.get(id);
            if (old == null || old.packedPos != packed || old.level != light) {
                if (old != null) dirty(BlockPos.of(old.packedPos), old.level);
                dirty(sourceBlock, light);
                last.put(id, new CachedSource(packed, light));
            }
        }

        var iterator = last.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, CachedSource> entry = iterator.next();
            if (!seen.contains(entry.getKey())) {
                CachedSource old = entry.getValue();
                dirty(BlockPos.of(old.packedPos), old.level);
                iterator.remove();
            }
        }

        active = next.toArray(new Source[0]);
    }

    private static void dirty(BlockPos pos, int light) {
        LevelRenderer renderer = Minecraft.getInstance().levelRenderer;
        if (renderer == null) return;

        int radius = light + 1;
        int minX = (pos.getX() - radius) >> 4;
        int maxX = (pos.getX() + radius) >> 4;
        int minY = (pos.getY() - radius) >> 4;
        int maxY = (pos.getY() + radius) >> 4;
        int minZ = (pos.getZ() - radius) >> 4;
        int maxZ = (pos.getZ() + radius) >> 4;

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    try {
                        renderer.setSectionDirty(x, y, z);
                    } catch (Throwable ignored) {
                        // A section may unload between the scan and render invalidation.
                    }
                }
            }
        }
    }

    private static final class Source {
        final double x, y, z;
        final int level;

        Source(double x, double y, double z, int level) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.level = level;
        }
    }

    private static final class CachedSource {
        final long packedPos;
        final int level;

        CachedSource(long packedPos, int level) {
            this.packedPos = packedPos;
            this.level = level;
        }
    }
}
